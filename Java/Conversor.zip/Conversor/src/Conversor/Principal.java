package Conversor;
    
public class Principal {
    public static void main(String[] args) {      //Funcion main (principal)
        Ventana v1 = new Ventana();     //Definimos una ventana
        v1.setVisible(true);    //Hacemos visible la ventana
    }  
}
