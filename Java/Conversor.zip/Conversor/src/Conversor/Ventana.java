package Conversor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Ventana extends JFrame {
        
    private JPanel panel;    
    private JRadioButton boton1, boton2, boton3, boton4,boton5,boton6,boton7,boton8;    
    private JTextField entrada;  
    private JButton salida;
    Operaciones op = new Operaciones();
    
    public Ventana(){
        setSize(500,500);   //Creamos la ventana
        setDefaultCloseOperation(EXIT_ON_CLOSE);    //Funcion para termina el programa al cerrar la ventana
        setTitle("Programa de Conversiones");   //Insertamos titulo en la ventana  
        setLocationRelativeTo(null);    //Posiciona la ventana al centro de la pantalla
        Interfaz();   //Insertamos todos los elementos en la ventana
    }       
        
    private void Interfaz(){    
        Panel();   //Mandamos a llamar el panel
        Etiquetas();   //Mandamos a llamar las etiquetas 
        Botones();   //Mandamos a llamar los botones
        CajaTexto();   //Mandamos a llamar la caja de texto
    }
    
    private void Panel(){
        panel = new JPanel();   //Creamos el panel
        this.getContentPane().add(panel);   //Agregamos el panel a la ventana    
        panel.setLayout(null);   //Desactivamos el diseño del panel por defecto
    }    
        
    private void Etiquetas(){    
        JLabel etiqueta1 = new JLabel("Ingresa un numero y selecciona su base.",SwingConstants.LEFT);   //Creamos una etiqueta
        JLabel etiqueta2 = new JLabel("Numero: ",SwingConstants.LEFT);  
        JLabel etiqueta3 = new JLabel("Base:",SwingConstants.LEFT);
        JLabel etiqueta4 = new JLabel("Convertir a base:",SwingConstants.LEFT);
        JLabel etiqueta9 = new JLabel("Elaborado por Jose Antonio Sanchez Alanis.",SwingConstants.RIGHT);  
        DiseñoDeEtiquetas(etiqueta1, 25, 30, 265, 20);   //Definimos la caracteristicas de la etiqueta
        DiseñoDeEtiquetas(etiqueta2, 25, 80, 60, 20);
        DiseñoDeEtiquetas(etiqueta3, 25, 120, 40, 20);
        DiseñoDeEtiquetas(etiqueta4, 25, 205, 200, 20);
    
        panel.add(etiqueta9);   //Agegamos las etiquetas al panel
        etiqueta9.setBounds(250, 430, 225, 20);   //Definimos Posicion y tamaño de la etiquetas
        etiqueta9.setFont(new Font("Tw Cen MT 13",1,10));   //Definimos fuentes de la etiquetas
    }    
        
    private void DiseñoDeEtiquetas(JLabel etiqueta, int x, int y, int ancho, int alto){   
        panel.add(etiqueta);   //Agregamos al panel de las etiquetas
        etiqueta.setBounds(x, y, ancho, alto);     //Definimos Posicion y tamaño de las etiquetas
        etiqueta.setFont(new Font("Tw Cen MT 13",0,14));//Definimos fuente de las etiquetas  
    }   
    
    private void Botones(){
        boton1 = new JRadioButton("Binario",true);   //Creamos los botones para seleccionar la base
        boton2 = new JRadioButton("Octal",false);
        boton3 = new JRadioButton("Decimal",false);
        boton4 = new JRadioButton("Hexadecimal",false);
        
        DiseñoDeBotones(boton1, 25, 150, 110, 20);   //Definimos el diseño de los botones
        DiseñoDeBotones(boton2, 135, 150, 70, 20);
        DiseñoDeBotones(boton3, 225, 150, 110, 20);
        DiseñoDeBotones(boton4, 335, 150, 160, 20);
        
        ButtonGroup grupo = new ButtonGroup();   //Creamos un grupo de botones
        grupo.add(boton1);   //Agregamos los botones al grupo
        grupo.add(boton2);
        grupo.add(boton3);
        grupo.add(boton4);
        
        boton5 = new JRadioButton("Binario",false);   //Creamos los botones para elegir que conversion mostrar
        boton6 = new JRadioButton("Octal",false);
        boton7 = new JRadioButton("Decimal",false);
        boton8 = new JRadioButton("Hexadecimal",false);
        
        DiseñoDeBotones(boton5, 25, 240, 110, 20);   //Definimos el diseño de los botones
        DiseñoDeBotones(boton6, 25, 275, 70, 20);
        DiseñoDeBotones(boton7, 25, 310, 110, 20);
        DiseñoDeBotones(boton8, 25, 345, 155, 20);
        
        salida = new JButton("Convertir");   //Creamos el boton de conversion
        panel.add(salida);   //Agregamos al panel el boton
        salida.setBounds(190, 390, 120, 30);   //Definimos Posicion y tamaño del boton
        salida.setFont(new Font("Tw Cen MT 13",1,12));   //Definimos fuente del boton
        
        //EVENTOS

        JLabel etiqueta5 = new JLabel();   //Creamos las etiquetas que mostraran la conversiones
        JLabel etiqueta6 = new JLabel();
        JLabel etiqueta7 = new JLabel();
        JLabel etiqueta8 = new JLabel();
        
        DiseñoDeEtiquetas(etiqueta5, 180, 240, 350, 22);   //Diseñamos las etiquetas
        DiseñoDeEtiquetas(etiqueta6, 180, 275, 350, 22);
        DiseñoDeEtiquetas(etiqueta7, 180, 310, 350, 22);
        DiseñoDeEtiquetas(etiqueta8, 180, 345, 350, 22);
        
        ActionListener accion = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(ae.getSource()==salida){   //Condicional si el boton de conversion es presionado
                    String Bin, Oct, Hex;
                    long Dec, base;
                    boolean condicion;
                    
                    if (boton1.isSelected()) {   //Condicional si se elige la base 2
                    base = 2;
                    condicion = op.Verificar(entrada.getText(), base);   //Llamamos la funcion verificar para checar
                    if(condicion == false){                              //si el numero ingresado corresponde
                            etiqueta5.setText("");                       //a la base selecciona, de no ser asi
                            etiqueta6.setText("");                       //indica que el numero no corresponde
                            etiqueta7.setText("");                       //y vacia las etiquetas donde se muestran
                            etiqueta8.setText("");                       //las conversiones
                            JOptionPane.showMessageDialog(null,"El numero ingresado no corresponde a la base seleccionada.");
                            return;
                    }
                    Dec = op.ToDecimal(entrada.getText(), base);   //Convertimos el numero ingresado a decimal
                    
                    if (boton5.isSelected()) {   //Condicional si se elige la conversion a Binario
                        etiqueta5.setText(""+entrada.getText());
                    }else{etiqueta5.setText("");}
                    
                    if (boton6.isSelected()) {   //Condicional si se elige la conversion a Octal
                        Oct = op.ToOctal(Dec, base);
                        etiqueta6.setText(""+Oct);
                    }else{etiqueta6.setText("");}
                    
                    if (boton7.isSelected()) {   //Condicional si se elige la conversion a Decimal
                        etiqueta7.setText(""+Dec);
                    }else{etiqueta7.setText("");}
                    
                    if (boton8.isSelected()) {   //Condicional si se elige la conversion a Hexadecimal
                        Hex = op.ToHexadecimal(Dec, base);
                        etiqueta8.setText(""+Hex);
                    }else{etiqueta8.setText("");}
                    }
                    
                    if (boton2.isSelected()) {   //Condicional si se elige la base 8
                    base = 8;
                    condicion = op.Verificar(entrada.getText(), base);   //Llamamos la funcion verificar para checar
                    if(condicion == false){                              //si el numero ingresado corresponde
                            etiqueta5.setText("");                       //a la base selecciona, de no ser asi
                            etiqueta6.setText("");                       //indica que el numero no corresponde
                            etiqueta7.setText("");                       //y vacia las etiquetas donde se muestran
                            etiqueta8.setText("");                       //las conversiones
                            JOptionPane.showMessageDialog(null,"El numero ingresado no corresponde a la base seleccionada.");
                            return;
                    }
                    Dec = op.ToDecimal(entrada.getText(), base);   //Convertimos el numero ingresado a decimal
                    
                    if (boton5.isSelected()) {   //Condicional si se elige la conversion a Binario
                    Bin = op.ToBinario(Dec, base);
                    etiqueta5.setText(""+Bin);
                    }else{etiqueta5.setText("");}
                    
                    if (boton6.isSelected()) {   //Condicional si se elige la conversion a Octal
                        etiqueta6.setText(""+entrada.getText());
                    }else{etiqueta6.setText("");}
                    
                    if (boton7.isSelected()) {   //Condicional si se elige la conversion a Decimal
                        etiqueta7.setText(""+Dec);
                    }else{etiqueta7.setText("");}
                    
                    if (boton8.isSelected()) {   //Condicional si se elige la conversion a Hexadecimal
                        Hex = op.ToHexadecimal(Dec, base);
                        etiqueta8.setText(""+Hex);
                    }else{etiqueta8.setText("");}
                    }
                if (boton3.isSelected()) {   //Condicional si se elige la base 10
                    base = 10;
                    condicion = op.Verificar(entrada.getText(), base);   //Llamamos la funcion verificar para checar
                    if(condicion == false){                              //si el numero ingresado corresponde
                            etiqueta5.setText("");                       //a la base selecciona, de no ser asi
                            etiqueta6.setText("");                       //indica que el numero no corresponde
                            etiqueta7.setText("");                       //y vacia las etiquetas donde se muestran
                            etiqueta8.setText("");                       //las conversiones
                            JOptionPane.showMessageDialog(null,"El numero ingresado no corresponde a la base seleccionada.");
                            return;
                    }
                    Dec = op.ToDecimal(entrada.getText(), base);   //Convertimos el numero ingresado a decimal
                    
                    if (boton5.isSelected()) {   //Condicional si se elige la conversion a Binario
                    Bin = op.ToBinario(Dec, base);
                    etiqueta5.setText(""+Bin);
                    }else{etiqueta5.setText("");}
                    
                    if (boton6.isSelected()) {   //Condicional si se elige la conversion a Octal
                        Oct = op.ToOctal(Dec, base);
                        etiqueta6.setText(""+Oct);
                    }else{etiqueta6.setText("");}
                    
                    if (boton7.isSelected()) {   //Condicional si se elige la conversion a Decimal
                        etiqueta7.setText(""+entrada.getText());
                    }else{etiqueta7.setText("");}
                    
                    if (boton8.isSelected()) {   //Condicional si se elige la conversion a Hexadecimal
                        Hex = op.ToHexadecimal(Dec, base);
                        etiqueta8.setText(""+Hex);
                    }else{etiqueta8.setText("");}
                    }
                if (boton4.isSelected()) {   //Condicional si se elige la base 16
                    base = 16;
                    condicion = op.Verificar(entrada.getText(), base);   //Llamamos la funcion verificar para checar
                    if(condicion == false){                              //si el numero ingresado corresponde
                            etiqueta5.setText("");                       //a la base selecciona, de no ser asi
                            etiqueta6.setText("");                       //indica que el numero no corresponde
                            etiqueta7.setText("");                       //y vacia las etiquetas donde se muestran
                            etiqueta8.setText("");                       //las conversiones
                            JOptionPane.showMessageDialog(null,"El numero ingresado no corresponde a la base seleccionada.");
                            return;
                    }
                    Dec = op.ToDecimal(entrada.getText(), base);   //Convertimos el numero ingresado a decimal
                    
                    if (boton5.isSelected()) {   //Condicional si se elige la conversion a Binario
                    Bin = op.ToBinario(Dec, base);
                    etiqueta5.setText(""+Bin);
                    }else{etiqueta5.setText("");}
                    
                    if (boton6.isSelected()) {   //Condicional si se elige la conversion a Octal
                        Oct = op.ToOctal(Dec, base);
                        etiqueta6.setText(""+Oct);
                    }else{etiqueta6.setText("");}
                    
                    if (boton7.isSelected()) {   //Condicional si se elige la conversion a Decimal
                        etiqueta7.setText(""+Dec);
                    }else{etiqueta7.setText("");}
                    
                    if (boton8.isSelected()) {   //Condicional si se elige la conversion a Hexadecimal
                        etiqueta8.setText(""+entrada.getText());
                    }else{etiqueta8.setText("");}
                    }
                }                
            }
        };
        salida.addActionListener(accion);
    }
    
    private void DiseñoDeBotones(JRadioButton boton, int x, int y, int ancho, int alto){   
        panel.add(boton);   //Agregamos al panel los botones
        boton.setBounds(x, y, ancho, alto);   //Definimos Posicion y tamaño de los botones
        boton.setFont(new Font("Tw Cen MT 13",0,14));   //Definimos Fuente de os botones
    }  
    
    private void CajaTexto(){
        entrada = new JTextField();   //Creamos una caja de texto donde ingresaremos el numero a convertir
        entrada.setBounds(137, 81, 300, 22);   //Definimos posicion y tamaño de la caja de texto
        panel.add(entrada);   //Insertamos la caja en el panel
    }  
}