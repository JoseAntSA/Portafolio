
package Conversor;

import static java.lang.Math.pow;

public class Operaciones {      //Funcion de operaciones

    public long ToDecimal(String numero,long base){      //Funcion para convertir a Decimal
        long decimal = 0;
        long[] aux, arr;
        aux = new long[80];
        arr = new long[80];
     
           
        for(int i=0 ; i<numero.length() ; i++){    //Ciclo para convertir el caracter de ASCCI a numero correspondiente
            if(numero.charAt(i)>='a' && numero.charAt(i)<='z')
                arr[i] = numero.charAt(i) - 87;    //Agregamos cada digito a un arreglo
            if(numero.charAt(i)>='A' && numero.charAt(i)<='Z')
                arr[i] = numero.charAt(i) - 55;
            if(numero.charAt(i)>='0' &&numero.charAt(i)<='9')
                arr[i] = numero.charAt(i) - 48;    
        }
        
        
        for(int i=0 ; i<numero.length() ; i++){    //Ciclo para invertir el arreglo de los digitos
            aux[i] = arr[numero.length()-i-1]; 
        }
         
        for(int i=0 ; i<numero.length() ; i++){    //Ciclo para pasar el numero a decimal
            decimal += (aux[i])*pow(base,i);
        } 
        return decimal;
    }
    
    public String ToBinario(long decimal, long base){      //Funcion para convertir a Binario
        int tam = 0;
        String Binario = "";
        char[]  arr;
        arr = new char[80];
        
        for(int i=0 ; decimal>0 ; i++){     //Ciclo para pasar de decimal a binario
    	    arr[i] = (char) ((decimal%2)+48);
     	    decimal /= 2;
            tam++;
	} 
        
        for(int i=tam ; 0<i ; i--){    //Ciclo para concatenar los digitos del numero binario
	    Binario += arr[i-1];  
	} 
        return Binario;
    }
    public String ToOctal(long decimal, long base){      //Funcion para convertir a Octal
        int tam = 0;
        String Octal = "";
        char[]  arr;
        arr = new char[80];
        
        for(int i=0 ; decimal>0 ; i++){     //Ciclo para pasar de decimal a Octal
    	    arr[i] = (char) ((decimal%8)+48);
     	    decimal /= 8;
            tam++;
	} 
        
        for(int i=tam ; 0<i ; i--){    //Ciclo para concatenar los digitos del numero Octal
	    Octal += arr[i-1];  
	} 
        return Octal;
    } 
    public String ToHexadecimal(long decimal, long base){      //Funcion para convertir a Hexadecimal
        int tam = 0;
        String Hexadecimal = "";
        char[]  arr;
        arr = new char[80];
        
        for(int i=0 ; decimal>0 ; i++){     //Ciclo para pasar de decimal a Hexadecimal
            if(decimal%16>=10 && decimal%16<=15)
                arr[i] = (char) ((decimal%16)+55);
            if(decimal%16>=0 && decimal%16<=9)
                arr[i] = (char) ((decimal%16)+48);    
    	    
     	    decimal /= 16;
            tam++;
	} 
        
        for(int i=tam ; 0<i ; i--){    //Ciclo para concatenar los digitos del numero Hexadecimal
	    Hexadecimal += arr[i-1];  
	} 
        return Hexadecimal;
    }
    public boolean Verificar(String numero,long base){      //Funcion para verificar si el numero
        boolean correcto = true;                           //ingresado corresponde a la base 
        int[] arr;                                         //seleccionada
        arr = new int[80];
     
           
        for(int i=0 ; i<numero.length() ; i++){
            if(numero.charAt(i)>='a' && numero.charAt(i)<='z')
                arr[i] = numero.charAt(i) - 87;
            if(numero.charAt(i)>='A' && numero.charAt(i)<='Z')
                arr[i] = numero.charAt(i) - 55;
            if(numero.charAt(i)>='0' &&numero.charAt(i)<='9')
                arr[i] = numero.charAt(i) - 48;    
        }
        for(int i=0 ; i<numero.length() ; i++){     //Ciclo para ver si algun digito es mayor
            if(arr[i]>=base){                       //o igual a labase seleccionada
                correcto = false;
                break;
            }
        }
        return correcto;
    }      
}
