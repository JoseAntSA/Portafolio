/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3_clasificador_kmeans_5dist;

/**
 *
 * @author anton
 */
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Frame extends JFrame{
	
    //Atributos
    private JFrame frame;
    private JPanel pnl1, pnl2;
    private JLabel etqTitle, etqDiv, etqDist, etqPlano, etqDiv2, etqDiv3;
    private JButton btnDatos;
    private JRadioButton rdBtn2D, rdBtn3D, rdBtnDist1, rdBtnDist2, rdBtnDist3, rdBtnDist4;
    private ButtonGroup grupoDist, grupoPlano;
    private ArrayList<Punto> lista;
    private float xMin, xMax, yMin, yMax, zMin, zMax;
    private int noDatos, noClases;
    private boolean val;
    private Plano pl;
    
    //Constructor
    public Frame(){
        frame = this;
        setTitle("Clasificador KNN");
        setSize(585,390);
        setResizable(false);
        setLocationRelativeTo(null);
        initComponets();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        addWindowListener(new EventoJFrame());
    }


    public void initComponets(){

        //CODIGO ATRIBUTOS
        Font fuenteEqt = new Font( "Tw Cen MT", 1, 26 );
        Font fuenteLet = new Font( "Tw Cen MT", 1, 13 );
        Font fuenteLet2 = new Font( "Tw Cen MT", 3, 15 );
        Color colorFondo = new Color(51,53,58);
        Color colorLetra = new Color(155,158,158);
        Color colorBtn = new Color(31,33,38);
        UIManager.put("OptionPane.background", colorFondo);
        UIManager.put("Panel.background", colorFondo);
        UIManager.put("OptionPane.messageForeground", colorLetra);
        UIManager.put("Button.font", fuenteLet);
        UIManager.put("Button.background", colorBtn);
        UIManager.put("Button.focus", colorBtn);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("RadioButton.focus", colorFondo);
        UIManager.put("RadioButton.background", colorFondo);
        UIManager.put("RadioButton.foreground", colorLetra);
        UIManager.put("RadioButton.font", fuenteLet );
	
        
        //CODIGO PANEL PRINCIPAL
        pnl1 = new JPanel();
        this.getContentPane().add(pnl1);
        pnl1.setBackground(colorFondo);
        pnl1.setLayout(null);


        //CODIGO TITULO
        etqTitle = new JLabel("Clasificador K-Means Clustering", SwingConstants.CENTER);
        etqTitle.setForeground(colorLetra);
        etqTitle.setBounds(20,30,535,30);
        etqTitle.setFont( fuenteEqt );
        pnl1.add(etqTitle);

        etqDiv = new JLabel();
        etqDiv.setBounds(50,65,480,3);
        etqDiv.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, colorLetra));
        pnl1.add(etqDiv);

        //CODIGO BOTON DATOS
        btnDatos = new JButton("Inicializar datos");
        btnDatos.setBounds(222,100,140,30);
        btnDatos.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, colorLetra)); 
        btnDatos.setFocusPainted(false);
        btnDatos.addActionListener(new EventoBotonInicio());
        pnl1.add(btnDatos);
        
        //CODIGO RADIOBOTONS DISTANCIAS
        etqDist = new JLabel("Distancias", SwingConstants.CENTER);
        etqDist.setForeground(Color.WHITE);
        etqDist.setBounds(132,150,120,30);
        etqDist.setFont( fuenteLet2 );
        pnl1.add(etqDist);
        
        etqDiv2 = new JLabel();
        etqDiv2.setBounds(132,175,120,3);
        etqDiv2.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.WHITE));
        pnl1.add(etqDiv2);
        
        rdBtnDist1 = new JRadioButton("Chebyshev",true);
        rdBtnDist1.setBounds(140,200,95,20);
	pnl1.add(rdBtnDist1);
        
        rdBtnDist2 = new JRadioButton("Manhattan",false);
        rdBtnDist2.setBounds(140,230,95,20);
	pnl1.add(rdBtnDist2);
        
        rdBtnDist3 = new JRadioButton("Euclidiana",false);
        rdBtnDist3.setBounds(140,260,95,20);
	pnl1.add(rdBtnDist3);
        
        rdBtnDist4 = new JRadioButton("Minkowski (r=3)",false);
        rdBtnDist4.setBounds(140,290,125,20);
	pnl1.add(rdBtnDist4);
        
        grupoDist = new ButtonGroup();
        grupoDist.add(rdBtnDist1);
        grupoDist.add(rdBtnDist2);
        grupoDist.add(rdBtnDist3);
        grupoDist.add(rdBtnDist4);
        
        //CODIGO RADIOBOTONS PLANO
        etqDist = new JLabel("Planos", SwingConstants.CENTER);
        etqDist.setForeground(Color.WHITE);
        etqDist.setBounds(332,150,120,30);
        etqDist.setFont( fuenteLet2 );
        pnl1.add(etqDist);
        
        etqDiv2 = new JLabel();
        etqDiv2.setBounds(332,175,120,3);
        etqDiv2.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.WHITE));
        pnl1.add(etqDiv2);
        
        rdBtn2D = new JRadioButton("2D",true);
        rdBtn2D.setBounds(369,200,45,20);
	pnl1.add(rdBtn2D);
        
        rdBtn3D = new JRadioButton("3D",false);
        rdBtn3D.setBounds(369,230,45,20);
	pnl1.add(rdBtn3D);
        
        grupoPlano = new ButtonGroup();
        grupoPlano.add(rdBtn2D);
        grupoPlano.add(rdBtn3D);
    }
    
    //CODIGO EVENTO WINDOW
	public class EventoJFrame implements WindowListener{
	    public void windowActivated(WindowEvent e){
                //Evento nulo
	    }

	    public void windowClosed(WindowEvent e){
	        //Evento nulo
	    }

	    public void windowClosing(WindowEvent e){
	        //Evento nulo
	    }

	    public void windowDeactivated(WindowEvent e){
	        //Evento nulo
	    }

	    public void windowDeiconified(WindowEvent e){
	        //Evento nulo
	    }

	    public void windowIconified(WindowEvent e){
	     	//Evento nulo   
	    }

            @Override
	    public void windowOpened(WindowEvent e){
                String s = "1. Seleccina una distancia y el plano donde se trabajara.";
                s += "\n2. Presione el boton 'Inicializar datos'";
                s += "\n2. Introduza los limites de los ejes, el no. de datos";
                s += "\n    y el no. de clases para la clasificacion.";
                JOptionPane.showMessageDialog(frame, s,"Modo de uso",JOptionPane.INFORMATION_MESSAGE); 
	    }
	}
    
    //CODIGO EVENTO ACTION
    public class EventoBotonInicio implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ev){
            SubFrame1 vtn;
            if(rdBtn2D.isSelected()){
                vtn = new SubFrame1(frame, false);
            }
            else{
                vtn = new SubFrame1(frame, true);
            }
            
            if (vtn.getVal()){
                val = true;
                xMin = vtn.getXmin();
                xMax = vtn.getXmax();
                yMin = vtn.getYmin();
                yMax = vtn.getYmax();
                noDatos = vtn.getDatos();
                noClases = vtn.getClases();

                if(val){
                    vtn.dispose();
                    
                    if(rdBtn2D.isSelected()){
                        iniciarDatos2D(noDatos);
                        pl = new Plano(xMin, xMax, yMin, yMax );
                        //pl.limpiar();
                        pl.crearColores(noClases);

                        Grafica2D graf2D = new Grafica2D(pl, lista, noClases, tipoDist());
                    }else{
                        zMin = vtn.getZmin();
                        zMax = vtn.getZmax();
                        iniciarDatos3D(noDatos);
                        
                        Grafica3D graf3D = new Grafica3D(lista, noClases, tipoDist());
                        graf3D.setXYZ(xMin, xMax, yMin, yMax, zMin, zMax);
                        try {
                            graf3D.iniciarProceso();
                        } catch (IOException ex) {
                            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    
                }
            }
        }//evento
    }//clase interna      

    //METODOS 
    public void iniciarDatos2D( int nP ){
        //random()*(xMax-xMin)+xMin
        float x, y;
        Punto ptn;
        lista = new ArrayList<>();
        
        for(int i=0 ; i<nP ; i++ ){
            ptn = new Punto();
            
            x = (float)Math.random()*(xMax-xMin)+(xMin);
            y = (float)Math.random()*(yMax-yMin)+(yMin);

            ptn.setPx(x);
            ptn.setPy(y); 
            lista.add(ptn);
        }
    }
    
    public void iniciarDatos3D( int nP ){
        //random()*(xMax-xMin)+xMin
        float x, y, z;
        Punto ptn;
        lista = new ArrayList<>();
        
        for(int i=0 ; i<nP ; i++ ){
            ptn = new Punto();
            
            x = (float)Math.random()*(xMax-xMin)+(xMin);
            y = (float)Math.random()*(yMax-yMin)+(yMin);
            z = (float)Math.random()*(zMax-zMin)+(zMin);
            
            ptn.setPx(x);
            ptn.setPy(y);
            ptn.setPz(z);
            lista.add(ptn);
        }
    }
    
    public String tipoDist(){
        if(rdBtn2D.isSelected()){
            if(rdBtnDist1.isSelected())
                return "21";
            else if(rdBtnDist2.isSelected())
                return "22";
            else if(rdBtnDist3.isSelected())
                return "23";
            else
                return "24";
        }
        else{
            if(rdBtnDist1.isSelected())
                return "31";
            else if(rdBtnDist2.isSelected())
                return "32";
            else if(rdBtnDist3.isSelected())
                return "33";
            else
                return "34";
        }
    }  
}

