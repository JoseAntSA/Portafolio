/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3_clasificador_kmeans_5dist;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author anton
 */
public class Grafica2D extends JFrame{
    
     //Atributos
    private JFrame frame;
    private JPanel pnl1, pnl2;
    private Plano pl;
    private ArrayList<Punto> lista;
    private ArrayList<Centroide> centroides;
    private int noClases, cont;
    private String tipoDist;
    private EventoPanel mouse;
    
    //Constructor
    public Grafica2D(Plano pl, ArrayList<Punto> lista, int noClases, String tipoDist){
        this.pl = pl;
        this.lista = lista;
        this.noClases = noClases;
        this.tipoDist = tipoDist;
        mouse = new EventoPanel();
        setTitle("Clasificador KNN en 2D");
        setSize(865,590);
        setResizable(false);
        setLocationRelativeTo(null);
        initComponets();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        addWindowListener(new EventoJFrame());
    }
    
     public void initComponets(){

        //CODIGO ATRIBUTOS
        Font fuenteLet = new Font( "Tw Cen MT", 1, 13 );
        Color colorFondo = new Color(51,53,58);
        Color colorLetra = new Color(155,158,158);
        Color colorBtn = new Color(31,33,38);
        UIManager.put("OptionPane.background", colorFondo);
        UIManager.put("Panel.background", colorFondo);
        UIManager.put("OptionPane.messageForeground", colorLetra);
        UIManager.put("Button.font", fuenteLet);
        UIManager.put("Button.background", colorBtn);
        UIManager.put("Button.focus", colorBtn);
        UIManager.put("Button.foreground", Color.WHITE);

        //CODIGO PANEL PRINCIPAL
        pnl1 = new JPanel();
        this.getContentPane().add(pnl1);
        pnl1.setBackground(colorFondo);
        pnl1.setLayout(null);


        //CODIGO GRAFICA
        pnl2 = new JPanel();
        pnl2.setBackground(Color.WHITE);
        pnl2.setLayout(null);
        pnl2.setBounds(30,30,800,500);
        pnl2.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
        pnl1.add(pnl2);
        
        pl.setPnl(pnl2);
    }
     
    
     //CODIGO EVENTO WINDOW
    public class EventoJFrame implements WindowListener{
        public void windowActivated(WindowEvent e){
            //Evento nulo
        }

        public void windowClosed(WindowEvent e){
            //Evento nulo
        }

        public void windowClosing(WindowEvent e){
            //Evento nulo
        }

        public void windowDeactivated(WindowEvent e){
            //Evento nulo
        }

        public void windowDeiconified(WindowEvent e){
            //Evento nulo
        }

        public void windowIconified(WindowEvent e){
            //Evento nulo 
        }

        @Override
        public void windowOpened(WindowEvent e){
            String s = "<html><div style='text-align: center;'>";
            s += "Datos inicializados.<br><br>A continuacion se graficaran los datos<br>usando la distancia ";
            switch(tipoDist){
                case "21":
                    s += "Chebyshev";
                    break;
                case "22":
                    s += "Manhattan";
                    break;
                case "23":
                    s += "Euclidiana";
                    break;
                case "24":
                    s += "Minkowski de 3° grado";
                    break;
                default:
                    break;
            }
            s +=  "</div></html>";
            JOptionPane.showMessageDialog(frame, new JLabel(s, SwingConstants.CENTER), "Inicio de clasificacion", JOptionPane.PLAIN_MESSAGE);
            
            graficarDatos();
            
            s = "Seleccione " + noClases + " atractores";
            s += "\ndando clic dentro de la grafica";
            JOptionPane.showMessageDialog(frame, s,"Inicializacion de atractores",JOptionPane.INFORMATION_MESSAGE);

            cont = 0;
            centroides = new ArrayList<>();
            pnl2.addMouseListener(mouse);
            
        }
    }
    
    //CODIGO EVENTO MOUSE
    public class EventoPanel implements MouseListener{

        @Override
        public void mousePressed(MouseEvent e){
            //Se invoca cuando el botón del ratón fué pulsado.
            Centroide centro = new Centroide();
            
            centro.setPx( (e.getX()-pl.getCentX())*pl.getPixX() );
            centro.setPy( (-1)*(e.getY()-pl.getCentY())*pl.getPixY() );
            centro.setClase(cont+1);
            
            pl.dibujarCentroide(centro.getPx(), centro.getPy());
            centroides.add(centro);
            
            cont++;
            if(cont==noClases){
                pnl2.removeMouseListener(mouse);
         
                String s = "Iniciara la clasificacion!";
                JOptionPane.showMessageDialog(frame, s,"",JOptionPane.INFORMATION_MESSAGE);
                
                try {
                    algoritmoKMeans();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }  
        }
        @Override
        public void mouseReleased(MouseEvent e){
            //Se invoca cuando el botón del ratón fué soltado.
        }
        @Override
        public void mouseClicked(MouseEvent e){
            //Se invoca cuando el botón del ratón fué pulsado y soltado.
        }
        @Override
        public void mouseEntered(MouseEvent e){
            //Se invoca cuando el cursor del ratón entró a un componente.
        }      
        @Override
        public void mouseExited(MouseEvent e){
            //Se invoca cuando el cursor del ratón salió de un componente.
        }
    }//clase interna*/
     
     
    public void graficarDatos( ){
        float x, y;
        int clase;
        
        pl.dibujarCartesiano();
        if(lista.size()>=80000){
            for(int i=0 ; i<80000 ; i++){
                x = lista.get(i).getPx();
                y = lista.get(i).getPy();
                clase = lista.get(i).getClase();

                pl.dibujarPunto(x,y,clase);
            }
        }else{
            for(Punto ptnTemp: lista){
                x = ptnTemp.getPx();
                y = ptnTemp.getPy();
                clase = ptnTemp.getClase();

                pl.dibujarPunto(x,y,clase);
            }
        }   
    }
    
    public void algoritmoKMeans() throws InterruptedException{

        ArrayList<Centroide> tmp;
	float dist, x1, y1 ,x2 ,y2;
        int comp, iter=0;
        do{
            comp=0;
            iter++;
            for(Centroide cto: centroides){
                cto.inicializarSumas();
            }
            
            for(Punto ptn: lista){
        
                x1 = ptn.getPx();
                y1 = ptn.getPy();
                for(Centroide cto: centroides){
                    x2 = cto.getPx();
                    y2 = cto.getPy();
                    dist = calDist(x1, y1, x2, y2);
                    cto.setDist(dist);
                }
                Collections.sort(centroides);
                ptn.setClase(centroides.get(0).getClase());

                centroides.get(0).setSumX(centroides.get(0).getSumX()+x1);
                centroides.get(0).setSumY(centroides.get(0).getSumY()+y1);
                centroides.get(0).setCont(centroides.get(0).getCont()+1);
            }

            tmp = cloneArrayList(centroides);

            for(Centroide cto: centroides){
                cto.setPx(cto.getSumX()/((float)cto.getCont()));
                cto.setPy(cto.getSumY()/((float)cto.getCont()));
            }
            pl.limpiar();
            for(int i=0 ; i<noClases ; i++){
                if(Float.compare(tmp.get(i).getPx(),centroides.get(i).getPx())!=0){
                    comp++;
                }
                else if(Float.compare(tmp.get(i).getPy(),centroides.get(i).getPy())!=0){
                    comp++;
                }
            
            }
            if(iter<5){
                graficarDatos();
                for(int i=0 ; i<noClases ; i++){
                    pl.dibujarCentroide(tmp.get(i).getPx(), tmp.get(i).getPy());
                }
                Thread.sleep(2000);
            }
            
        }while(comp!=0);
        
        graficarDatos();
        for(int i=0 ; i<noClases ; i++){
                    pl.dibujarCentroide(tmp.get(i).getPx(), tmp.get(i).getPy());
        }
        Thread.sleep(2000);
        
        String s = "La clasificacion ha terminado,";
        s += "\nse necesitaron " + iter + " iteraciones.";
        
        JOptionPane.showMessageDialog(frame, s,"Clasificacion terminada",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public ArrayList<Centroide> cloneArrayList(ArrayList<Centroide> orig){
        ArrayList<Centroide> clon = new ArrayList<>(orig.size());
        for(Centroide item: orig){
            clon.add((Centroide)item.clone()); 
        }
        return clon; 
    }
     
    public float calDist(float x1, float y1, float x2, float y2){
        float dist = 0f;
    
        switch(tipoDist){
            case "21":
                dist = Float.max( Math.abs(x2-x1), Math.abs(y2-y1) );
                break;
            case "22":
                dist = Math.abs(x2-x1) + Math.abs(y2-y1);
                break;
            case "23":
                dist = (float)Math.sqrt( Math.pow((double)(x2-x1),2.0) + Math.pow((double)(y2-y1),2.0) );
                break;
            case "24":
                double distTmp = Math.abs(Math.pow((double)(x2-x1),3.0)) + Math.abs(Math.pow((double)(y2-y1),3.0));
                dist = (float)Math.pow( distTmp, (1.0/3.0));
                break;
            default:
                break;
        }
        return dist;
    } 
}


