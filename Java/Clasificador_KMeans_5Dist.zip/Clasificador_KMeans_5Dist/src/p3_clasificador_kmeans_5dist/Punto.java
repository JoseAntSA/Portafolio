/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3_clasificador_kmeans_5dist;

/**
 *
 * @author anton
 */
public class Punto{

    private float x, y, z;
    private int clase;
    
    public Punto(){
        clase = 0;
    }
    
    public void setPx( float x ){
        this.x = x;
    }//setPx
    public float getPx(){
      return x;
    }//getPx

    public void setPy( float y ){
        this.y = y;
    }//setPy
    public float getPy(){
        return y;
    }//getPy
   
    public void setPz( float z ){
        this.z = z;
    }//setPz
    public float getPz(){
        return z;
    }//getPz
    
    public void setClase( int clase ){
        this.clase = clase;
    }//setClase
    public int getClase(){
      return clase;
    }//getClase
    
}//Clase 
