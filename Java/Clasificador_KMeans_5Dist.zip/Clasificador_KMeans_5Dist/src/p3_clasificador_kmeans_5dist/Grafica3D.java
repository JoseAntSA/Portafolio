/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3_clasificador_kmeans_5dist;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import com.rinearn.graph3d.RinearnGraph3D;
import com.rinearn.graph3d.renderer.RinearnGraph3DRenderer;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author anton
 */
public class Grafica3D {
    
    private ArrayList<Punto> lista;
    private ArrayList<Centroide> centroides;
    private ArrayList<Color> colores;
    private int noClases, cont;
    private String tipoDist;
    private float xMin, xMax, yMin, yMax, zMin, zMax;
    private RinearnGraph3D graph = new RinearnGraph3D();
    private RinearnGraph3DRenderer renderer = graph.getRenderer();
    
    public Grafica3D(ArrayList<Punto> lista, int noClases, String tipoDist){
        this.lista = lista;
        this.noClases = noClases;
        this.tipoDist = tipoDist;
    }
    
    public void setXYZ(float xMin, float xMax, float yMin, float yMax, float zMin, float zMax){
        this.xMin = xMin;
        this.xMax = xMax;
        this.yMin = yMin;
        this.yMax = yMax;
        this.zMin = zMin;
        this.zMax = zMax;
    }
    
    
    public void initConf(){
        //CODIGO ATRIBUTOS
        Font fuenteLet = new Font( "Tw Cen MT", 1, 13 );
        Color colorFondo = new Color(51,53,58);
        Color colorLetra = new Color(155,158,158);
        Color colorBtn = new Color(31,33,38);
        UIManager.put("OptionPane.background", colorFondo);
        UIManager.put("Panel.background", colorFondo);
        UIManager.put("OptionPane.messageForeground", colorLetra);
        UIManager.put("Button.font", fuenteLet);
        UIManager.put("Button.background", colorBtn);
        UIManager.put("Button.focus", colorBtn);
        UIManager.put("Button.foreground", Color.WHITE);
        }
    
    public void iniciarProceso() throws IOException, InterruptedException{
        
        crearColores();
        inicializarGrafico();
        graficarDatos();
        inicializarCentroides();
        
        String s = "<html><div style='text-align: center;'>";
        s += "Datos inicializados.<br><br>A continuacion se graficaran los datos<br>usando la distancia ";
        switch(tipoDist){
            case "31":
                s += "Chebyshev";
                break;
            case "32":
                s += "Manhattan";
                break;
            case "33":
                s += "Euclidiana";
                break;
            case "34":
                s += "Minkowski de 3° grado";
                break;
            default:
                break;
        }
        
        s +=  "</div></html>";
        JOptionPane.showMessageDialog(null, new JLabel(s, SwingConstants.CENTER), "Inicio de clasificacion", JOptionPane.PLAIN_MESSAGE);
        
        
        s = "Iniciara la clasificacion!";
        JOptionPane.showMessageDialog(null, s,"",JOptionPane.INFORMATION_MESSAGE);
        
             
        algoritmoKMeans();
        
       
    }
    
    
    public void inicializarCentroides(){
            
        centroides = new ArrayList<>();

        Centroide centro;
        for(int i=1 ; i<=noClases ; i++){
            centro = new Centroide();
            centro.setPx( (float)Math.random()*(xMax-xMin)+(xMin) );
            centro.setPy( (float)Math.random()*(yMax-yMin)+(yMin) );
            centro.setPz( (float)Math.random()*(zMax-zMin)+(zMin) );
            centro.setClase(i);
            renderer.drawPoint(centro.getPx() , centro.getPy(), centro.getPz(), 8.0, colores.get(centro.getClase()));
            centroides.add(centro);
        }       
    }
    
    public void crearColores(){
        colores = new ArrayList<>();
        int r, g, b;
        
        colores.add(Color.BLACK);
        colores.add(new Color(149,188,17));
        colores.add(new Color(250,121,4));
        colores.add(new Color(11,152,208));
        colores.add(new Color(12,66,100));
        colores.add(new Color(255,222,23));
        
        for(int i=0 ; i<noClases; i++){
            r = (int)(Math.random()*255);       
            g = (int)(Math.random()*255);
            b = (int)(Math.random()*255);

            Color color = new Color(r,g,b);
            colores.add(color);
        }
    }
    
    public void inicializarGrafico() throws IOException{
        
        graph.setMenuVisible(false);
        graph.setWindowBounds(300, 100, 800, 500);
        graph.setWindowTitle("Clasificador KNN en 3D");
        graph.loadConfigurationFile​( new File("C:/Users/anton/Downloads/Drivers/Graph3D/RinearnGraph3DQuickSetting/Ver.5.6_Default.ini"));
        //Rango
        graph.setXRange((double)(xMin), (double)(xMax));
        graph.setYRange((double)(yMin), (double)(yMax));
        graph.setZRange((double)(zMin), (double)(zMax));
        renderer.render();
    }
    
    public void graficarDatos( ){  
        renderer = graph.getRenderer();
        double x, y, z;
        int clase;
        
        if(lista.size()>=80000){
            for(int i=0 ; i<80000 ; i++){
                x = (double)lista.get(i).getPx();
                y = (double)lista.get(i).getPy();
                z = (double)lista.get(i).getPz();
                clase = lista.get(i).getClase();
                renderer.drawPoint(x , y, z, 3.0, colores.get(clase));
                //renderer.render();
            }
        }else{
            for(Punto ptnTemp: lista){
                x = (double)ptnTemp.getPx();
                y = (double)ptnTemp.getPy(); 
                z = (double)ptnTemp.getPz(); 
                clase = ptnTemp.getClase();

                renderer.drawPoint(x , y, z, 3.0, colores.get(clase));
                //renderer.render();
            }
        }renderer.render(); 
    }
    
    public void algoritmoKMeans() throws InterruptedException, IOException{

        ArrayList<Centroide> tmp;
	float dist, x1, y1, z1, x2, y2, z2;
        int comp, iter=0;
        do{
            comp=0;
            iter++;
            for(Centroide cto: centroides){
                cto.inicializarSumas();
            }
            
            for(Punto ptn: lista){
        
                x1 = ptn.getPx();
                y1 = ptn.getPy();
                z1 = ptn.getPz();
                for(Centroide cto: centroides){
                    x2 = cto.getPx();
                    y2 = cto.getPy();
                    z2 = cto.getPz();
                    dist = calDist(x1, y1, z1, x2, y2, z2);
                    cto.setDist(dist);
                }
                Collections.sort(centroides);
                ptn.setClase(centroides.get(0).getClase());

                centroides.get(0).setSumX(centroides.get(0).getSumX()+x1);
                centroides.get(0).setSumY(centroides.get(0).getSumY()+y1);
                centroides.get(0).setSumZ(centroides.get(0).getSumZ()+z1);
                centroides.get(0).setCont(centroides.get(0).getCont()+1);
            }

            tmp = cloneArrayList(centroides);

            for(Centroide cto: centroides){
                cto.setPx(cto.getSumX()/((float)cto.getCont()));
                cto.setPy(cto.getSumY()/((float)cto.getCont()));
                cto.setPz(cto.getSumZ()/((float)cto.getCont()));
            }
            
            for(int i=0 ; i<noClases ; i++){
                if(Float.compare(tmp.get(i).getPx(),centroides.get(i).getPx())!=0){
                    comp++;
                }
                else if(Float.compare(tmp.get(i).getPy(),centroides.get(i).getPy())!=0){
                    comp++;
                }
                else if(Float.compare(tmp.get(i).getPz(),centroides.get(i).getPz())!=0){
                    comp++;
                }
            graph.clear();
            }
            //if(iter<5){
                
                //graficarDatos();
                //for(int i=0 ; i<noClases ; i++){
                //    renderer.drawPoint(tmp.get(i).getPx(), tmp.get(i).getPy(), tmp.get(i).getPz(),  8.0, colores.get(0));
                //}
                //renderer.render();
                //Thread.sleep(3000);
                //renderer.render();
            //}
            
        }while(comp!=0);
        //Thread.sleep(2000);
        graph.clear();
        graficarDatos();
        for(int i=0 ; i<noClases ; i++){
                    renderer.drawPoint(tmp.get(i).getPx(), tmp.get(i).getPy(), tmp.get(i).getPz(),  8.0, colores.get(0));
        }
        renderer.render();
        
        
        String s = "La clasificacion ha terminado,";
        s += "\nse necesitaron " + iter + " iteraciones.";
        
        JOptionPane.showMessageDialog(null, s,"Clasificacion terminada",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public ArrayList<Centroide> cloneArrayList(ArrayList<Centroide> orig){
        ArrayList<Centroide> clon = new ArrayList<>(orig.size());
        for(Centroide item: orig){
            clon.add((Centroide)item.clone()); 
        }
        return clon; 
    }
     
    public float calDist(float x1, float y1, float z1, float x2, float y2, float z2){
        float dist = 0f;
        float temp;
        switch(tipoDist){
            case "31":
                temp = Float.max( Math.abs(x2-x1), Math.abs(y2-y1));
                dist = Float.max( temp, Math.abs(z2-z1));
                break;
            case "32":
                dist = Math.abs(x2-x1) + Math.abs(y2-y1) + Math.abs(z2-z1);
                break;
            case "33":
                dist = (float)Math.sqrt( Math.pow((double)(x2-x1),2.0) + Math.pow((double)(y2-y1),2.0) + Math.pow((double)(z2-z1),2.0) );
                break;
            case "34":
                double distTmp = Math.abs(Math.pow((double)(x2-x1),3.0)) + Math.abs(Math.pow((double)(y2-y1),3.0)) + Math.abs(Math.pow((double)(z2-z1),3.0));
                dist = (float)Math.pow( distTmp, (1.0/3.0));
                break;
            default:
                break;
        }
        return dist;
    } 
}
